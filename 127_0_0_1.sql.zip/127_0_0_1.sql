-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 31, 2020 at 06:35 AM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `inventorymanagement`
--
CREATE DATABASE IF NOT EXISTS `inventorymanagement` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `inventorymanagement`;

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` int(11) NOT NULL,
  `catname` varchar(50) NOT NULL,
  `active` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `catname`, `active`) VALUES
(1, 'Clothes', 1),
(2, 'Grocery', 1),
(3, 'Cosmetics', 1),
(4, 'snacks', 1),
(5, 'Electronics', 1),
(6, 'Toiletries', 1);

-- --------------------------------------------------------

--
-- Table structure for table `history`
--

CREATE TABLE `history` (
  `id` int(11) NOT NULL,
  `date` datetime NOT NULL DEFAULT current_timestamp(),
  `pname` varchar(50) NOT NULL,
  `qty` int(11) NOT NULL,
  `price` int(11) NOT NULL,
  `sby` varchar(50) NOT NULL,
  `invoiceno` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `history`
--

INSERT INTO `history` (`id`, `date`, `pname`, `qty`, `price`, `sby`, `invoiceno`) VALUES
(1, '2020-03-09 00:00:00', 'hand sanitizer', 10, 99999990, 'user1', 1),
(2, '2020-03-03 00:00:00', ' ice cream', 10, 100, 'user1', 1),
(3, '2020-03-05 00:00:00', 'toilet paper', 5, 25000, 'user3', 1),
(5, '2020-03-31 03:25:15', 'eggs', 5, 50, 'user1', 2),
(6, '2020-03-31 03:26:18', 'eggs', 5, 50, 'user1', 2),
(7, '2020-03-31 04:07:22', 'hand sanitizer', 5, 49999995, 'user1', 1078945),
(8, '2020-03-31 04:12:15', 'chicken', 5, 1000, 'user1', 8947158),
(9, '2020-03-31 04:12:15', 'patience', 5, 705032699, 'user1', 8947158),
(10, '2020-03-31 04:12:15', 'ice cream ', 5, 50, 'user1', 8947158),
(11, '2020-03-31 04:12:15', 'hand sanitizer', 5, 49999995, 'user1', 8947158),
(12, '2020-03-31 04:13:04', 'chicken', 5, 1000, 'user1', 9308107),
(13, '2020-03-31 04:13:04', 'hand sanitizer', 5, 49999995, 'user1', 9308107),
(14, '2020-03-31 04:13:14', 'eggs', 5, 50, 'user1', 7734404),
(15, '2020-03-31 04:13:25', 'hand sanitizer', 5, 49999995, 'user1', 8814263),
(16, '2020-03-31 04:13:35', 'eggs', 5, 50, 'user1', 7940227),
(17, '2020-03-31 04:14:13', 'patience', 5, 705032699, 'user1', 5608427),
(18, '2020-03-31 04:14:19', 'ice cream ', 5, 50, 'user1', 2286820),
(19, '2020-03-31 04:14:32', 'chicken', 5, 1000, 'user1', 4386106),
(20, '2020-03-31 04:15:34', 'ice cream ', 3, 30, '1', 4339864),
(21, '2020-03-31 04:17:42', 'chicken', 3, 600, 'user1', 9765616),
(22, '2020-03-31 04:22:21', 'chicken', 3, 600, 'user1', 1595469),
(23, '2020-03-31 04:22:43', 'chicken', 3, 600, 'user1', 4444735),
(24, '2020-03-31 04:23:00', 'eggs', 3, 30, 'user1', 3748905),
(25, '2020-03-31 04:27:43', 'hand sanitizer', 2, 1998, 'user1', 1598304),
(26, '2020-03-31 04:27:43', 'ice cream ', 2, 20, 'user1', 1598304),
(27, '2020-03-31 04:27:43', 'patience', 1, 999999, 'user1', 1598304),
(28, '2020-03-31 04:28:41', 'chicken', 94, 18800, 'user1', 7531550),
(29, '2020-03-31 04:28:41', 'eggs', 97, 970, 'user1', 7531550),
(30, '2020-03-31 04:28:41', 'hand sanitizer', 98, 97902, 'user1', 7531550),
(31, '2020-03-31 04:28:41', 'ice cream ', 98, 980, 'user1', 7531550),
(32, '2020-03-31 04:28:41', 'patience', 99, 98999901, 'user1', 7531550);

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `price` int(50) NOT NULL,
  `qty` int(50) NOT NULL,
  `catid` int(50) NOT NULL,
  `wareid` int(50) NOT NULL,
  `prodactive` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `name`, `price`, `qty`, `catid`, `wareid`, `prodactive`) VALUES
(1, 'hand sanitizer', 999, 100, 6, 1, 1),
(2, 'ice cream ', 25, 100, 4, 1, 1),
(3, 'chicken', 200, 0, 2, 1, 1),
(4, 'samsung s10', 99999, 100, 5, 2, 1),
(5, 'toilet paper', 5000, 100, 6, 3, 1),
(6, 'eggs', 10, 100, 2, 1, 1),
(7, 'patience', 999999, 0, 3, 1, 1),
(8, 'beef ', 450, 100, 2, 2, 1),
(9, 'wallet', 8000, 100, 1, 3, 1),
(13, 'hand sanitizer', 999, 100, 6, 2, 1),
(14, 'hand sanitizer', 999, 100, 6, 4, 1),
(28, 'Keyboard', 250, 100, 5, 1, 1),
(30, 'Mouse', 250, 100, 5, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `userinfo`
--

CREATE TABLE `userinfo` (
  `id` int(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `fname` varchar(50) NOT NULL,
  `lname` varchar(50) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `warehouse` int(11) DEFAULT NULL,
  `type` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `userinfo`
--

INSERT INTO `userinfo` (`id`, `username`, `password`, `email`, `fname`, `lname`, `phone`, `warehouse`, `type`) VALUES
(4, 'user2', 'user2', 'user2@email.com', 'useruser22', 'user2', '0153459', 2, 0),
(5, '2', '2', '2', '2ad', '2ad', '0122222', 0, 1),
(12, 'user1', 'user1', 'user1', 'user1', 'user1', '01514114', 1, 0),
(13, 'user3', 'user3', 'user3', 'user3', 'user3', '01234234', 3, 0),
(14, 'user4', 'user4', 'user4', 'user4', 'user4', '0144414', 4, 0),
(20, '1', '11', 'ad1', 'ad1', 'ad1', '01711430916', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `warehouse`
--

CREATE TABLE `warehouse` (
  `id``` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `active` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `warehouse`
--

INSERT INTO `warehouse` (`id``, `name`, `active`) VALUES
(1, 'gulshan1', 1),
(2, 'gulshan2', 1),
(3, 'mohakhali', 1),
(4, 'jahannam', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `history`
--
ALTER TABLE `history`
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD UNIQUE KEY `id` (`id`),
  ADD UNIQUE KEY `name` (`name`,`wareid`);

--
-- Indexes for table `userinfo`
--
ALTER TABLE `userinfo`
  ADD UNIQUE KEY `id` (`id`),
  ADD UNIQUE KEY `username` (`username`,`password`,`phone`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `history`
--
ALTER TABLE `history`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `userinfo`
--
ALTER TABLE `userinfo`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
